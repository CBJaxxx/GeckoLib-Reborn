/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.minecraftforge.common.extensions;

import java.util.Optional;
import java.util.function.BiConsumer;

import net.minecraft.client.Camera;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.SignalGetter;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.levelgen.feature.configurations.TreeConfiguration;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.tags.BlockTags;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.pathfinder.WalkNodeEvaluator;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.client.model.data.ModelDataManager;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.IPlantable;

import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("deprecation")
public interface IForgeBlock {
    private Block self() {
        return (Block)this;
    }

    /**
     * Gets the slipperiness at the given location at the given state. Normally
     * between 0 and 1.
     * <p>
     * Note that entities may reduce slipperiness by a certain factor of their own;
     * for {@link LivingEntity}, this is {@code .91}.
     * {@link ItemEntity} uses {@code .98}, and
     * {@link FishingHook} uses {@code .92}.
     *
     * @param state state of the block
     * @param level the level
     * @param pos the position in the level
     * @param entity the entity in question
     * @return the factor by which the entity's motion should be multiplied
     */
    default float getFriction(BlockState state, LevelReader level, BlockPos pos, @Nullable Entity entity) {
        return self().m_49958_();
    }

    /**
     * Get a light value for this block, taking into account the given state and coordinates, normal ranges are between 0 and 15
     *
     * @param state The state of this block
     * @param level The level this block is in
     * @param pos The position of this block in the level, will be {@link BlockPos#ZERO} when the chunk being loaded or
     *            generated calls this to check whether it contains any light sources
     * @return The light value
     * @implNote <ul>
     *     <li>
     *         If the given state of this block may emit light but requires position context to determine the light
     *         value, then it must return a non-zero light value if {@code (pos == BlockPos.ZERO)} in order for the
     *         chunk calling this to be considered as containing light sources.
     *     </li>
     *     <li>
     *         The given {@link BlockGetter} may be a chunk. Block, fluid or block entity accesses outside of its bounds
     *         will cause issues such as wrapping coordinates returning values from the opposing chunk edge
     *     </li>
     *     <li>
     *         This method may be called on a worker thread and must therefore use
     *         {@link IForgeBlockGetter#getExistingBlockEntity(BlockPos)} to retrieve the {@link BlockEntity}
     *         at the given position
     *     </li>
     * </ul>
     */
    default int getLightEmission(BlockState state, BlockGetter level, BlockPos pos) {
        return state.m_60791_();
    }

    /**
     * Checks if a player or entity can use this block to 'climb' like a ladder.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param entity The entity trying to use the ladder, CAN be null.
     * @return True if the block should act like a ladder
     */
    default boolean isLadder(BlockState state, LevelReader level, BlockPos pos, LivingEntity entity) {
        return state.m_204336_(BlockTags.f_13082_);
    }

    /**
     * Checks if this block makes an open trapdoor above it climbable.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param trapdoorState The current state of the open trapdoor above
     * @return True if the block should act like a ladder
     */
    default boolean makesOpenTrapdoorAboveClimbable(BlockState state, LevelReader level, BlockPos pos, BlockState trapdoorState) {
        return state.m_60734_() instanceof LadderBlock && state.m_61143_(LadderBlock.f_54337_) == trapdoorState.m_61143_(TrapDoorBlock.f_54117_);
    }

    /**
     * Determines if this block should set fire and deal fire damage
     * to entities coming into contact with it.
     *
     * @param level The current level
     * @param pos Block position in level
     * @return True if the block should deal damage
     */
    default boolean isBurning(BlockState state, BlockGetter level, BlockPos pos) {
        return this == Blocks.f_50083_ || this == Blocks.f_49991_;
    }

    /**
     * Determines if the player can harvest this block, obtaining it's drops when the block is destroyed.
     *
     * @param level The current level
     * @param pos The block's current position
     * @param player The player damaging the block
     * @return True to spawn the drops
     */
    default public boolean canHarvestBlock(BlockState state, BlockGetter level, BlockPos pos, Player player) {
        return ForgeHooks.isCorrectToolForDrops(state, player);
    }

    /**
     * Called when a player removes a block.  This is responsible for
     * actually destroying the block, and the block is intact at time of call.
     * This is called regardless of whether the player can harvest the block or
     * not.
     *
     * Return true if the block is actually destroyed.
     *
     * Note: When used in multiplayer, this is called on both client and
     * server sides!
     *
     * @param state The current state.
     * @param level The current level
     * @param player The player damaging the block, may be null
     * @param pos Block position in level
     * @param willHarvest True if Block.harvestBlock will be called after this, if the return in true.
     *        Can be useful to delay the destruction of tile entities till after harvestBlock
     * @param fluid The current fluid state at current position
     * @return True if the block is actually destroyed.
     */
    default boolean onDestroyedByPlayer(BlockState state, Level level, BlockPos pos, Player player, boolean willHarvest, FluidState fluid) {
        self().m_5707_(level, pos, state, player);
        return level.m_7731_(pos, fluid.m_76188_(), level.f_46443_ ? 11 : 3);
    }

    /**
     * Determines if this block is classified as a Bed, Allowing
     * players to sleep in it, though the block has to specifically
     * perform the sleeping functionality in it's activated event.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param player The player or camera entity, null in some cases.
     * @return True to treat this as a bed
     */
    default boolean isBed(BlockState state, BlockGetter level, BlockPos pos, @Nullable Entity player) {
        return self() instanceof BedBlock; //TODO: Forge: Keep isBed function?
    }

    /**
     * Returns the position that the entity is moved to upon
     * respawning at this block.
     *
     * @param state The current state
     * @param type The entity type used when checking if a dismount blockstate is dangerous. Currently always PLAYER.
     * @param levelReader The current level
     * @param pos Block position in level
     * @param orientation The angle the entity had when setting the respawn point
     * @param entity The entity respawning, often null
     * @return The spawn position or the empty optional if respawning here is not possible
     */
    default Optional<Vec3> getRespawnPosition(BlockState state, EntityType<?> type, LevelReader levelReader, BlockPos pos, float orientation, @Nullable LivingEntity entity) {
        if (isBed(state, levelReader, pos, entity) && levelReader instanceof Level level && BedBlock.m_49488_(level)) {
            return BedBlock.m_260958_(type, levelReader, pos, state.m_61143_(BedBlock.f_54117_), orientation);
        }
        return Optional.empty();
    }

    /**
     * Determines if a specified mob type can spawn on this block, returning false will
     * prevent any mob from spawning on the block.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param type The Mob Category Type
     * @return True to allow a mob of the specified category to spawn, false to prevent it.
     */
    default boolean isValidSpawn(BlockState state, BlockGetter level, BlockPos pos, SpawnPlacementType type, EntityType<?> entityType) {
        return state.m_60643_(level, pos, entityType);
    }

    /**
     * Called when a user either starts or stops sleeping in the bed.
     *
     * @param level The current level
     * @param pos Block position in level
     * @param sleeper The sleeper or camera entity, null in some cases.
     * @param occupied True if we are occupying the bed, or false if they are stopping use of the bed
     */
    default void setBedOccupied(BlockState state, Level level, BlockPos pos, LivingEntity sleeper, boolean occupied) {
        level.m_7731_(pos, state.m_61124_(BedBlock.f_49441_, occupied), 3);
    }

   /**
    * Returns the direction of the block. Same values that
    * are returned by BlockDirectional. Called every frame tick for every living entity. Be VERY fast.
    *
    * @param state The current state
    * @param level The current level
    * @param pos Block position in level
    * @return Bed direction
    */
    default Direction getBedDirection(BlockState state, LevelReader level, BlockPos pos) {
        return state.m_61143_(HorizontalDirectionalBlock.f_54117_);
    }

    /**
     * Location sensitive version of getExplosionResistance
     *
     * @param level The current level
     * @param pos Block position in level
     * @param explosion The explosion
     * @return The amount of the explosion absorbed.
     */
    default float getExplosionResistance(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return self().m_7325_();
    }

    /**
     *  Allows a block to override the standard EntityLivingBase.updateFallState
     *  particles, this is a server side method that spawns particles with
     *  WorldServer.spawnParticle.
     *
     * @param level The current server level
     * @param pos The position of the block.
     * @param state2 The state at the specific level/pos
     * @param entity The entity that hit landed on the block
     * @param numberOfParticles That vanilla level have spawned
     * @return True to prevent vanilla landing particles from spawning
     */
    default boolean addLandingEffects(BlockState state1, ServerLevel level, BlockPos pos, BlockState state2, LivingEntity entity, int numberOfParticles) {
        return false;
    }

   /**
    * Allows a block to override the standard vanilla running particles.
    * This is called from Entity.spawnSprintParticle and is called both,
    * Client and server side, it's up to the implementor to client check / server check.
    * By default vanilla spawns particles only on the client and the server methods no-op.
    *
    * @param state  The BlockState the entity is running on.
    * @param level  The level.
    * @param pos    The position at the entities feet.
    * @param entity The entity running on the block.
    * @return True to prevent vanilla running particles from spawning.
    */
    default boolean addRunningEffects(BlockState state, Level level, BlockPos pos, Entity entity) {
        return false;
    }

   /**
    * Determines if this block can support the passed in plant, allowing it to be planted and grow.
    * Some examples:
    *   Reeds check if its a reed, or if its sand/dirt/grass and adjacent to water
    *   Cacti checks if its a cacti, or if its sand
    *   Nether types check for soul sand
    *   Crops check for tilled soil
    *   Caves check if it's a solid surface
    *   Plains check if its grass or dirt
    *   Water check if its still water
    *
    * @param state The Current state
    * @param level The current level
    *
    * @param facing The direction relative to the given position the plant wants to be, typically its UP
    * @param plantable The plant that wants to check
    * @return True to allow the plant to be planted/stay.
    */
    boolean canSustainPlant(BlockState state, BlockGetter level, BlockPos pos, Direction facing, IPlantable plantable);

    /**
     * Called when a tree grows on top of this block and tries to set it to dirt by the trunk placer.
     * An override that returns true is responsible for using the place function to
     * set blocks in the world properly during generation. A modded grass block might override this method
     * to ensure it turns into the corresponding modded dirt instead of regular dirt when a tree grows on it.
     * For modded grass blocks, returning true from this method is NOT a substitute for adding your block
     * to the #minecraft:dirt tag, rather for changing the behaviour to something other than setting to dirt.
     *
     * NOTE: This happens DURING world generation, the generation may be incomplete when this is called.
     * Use the placeFunction when modifying the level.
     *
     * @param state The current state
     * @param level The current level
     * @param placeFunction Function to set blocks in the level for the tree, use this instead of the level directly
     * @param randomSource The random source
     * @param pos Position of the block to be set to dirt
     * @param config Configuration of the trunk placer. Consider azalea trees, which should place rooted dirt instead of regular dirt.
     * @return True to ignore vanilla behaviour
     */
    default boolean onTreeGrow(BlockState state, LevelReader level, BiConsumer<BlockPos, BlockState> placeFunction, RandomSource randomSource, BlockPos pos, TreeConfiguration config) {
        return false;
    }

   /**
    * Checks if this soil is fertile, typically this means that growth rates
    * of plants on this soil will be slightly sped up.
    * Only vanilla case is tilledField when it is within range of water.
    *
    * @param level The current level
    * @param pos Block position in level
    * @return True if the soil should be considered fertile.
    */
    default boolean isFertile(BlockState state, BlockGetter level, BlockPos pos) {
        if (state.m_60713_(Blocks.f_50093_))
            return state.m_61143_(FarmBlock.f_53243_) > 0;

        return  false;
    }

    /**
     * Determines if this block can be used as the frame of a conduit.
     *
     * @param level The current level
     * @param pos Block position in level
     * @param conduit Conduit position in level
     * @return True, to support the conduit, and make it active with this block.
     */
    default boolean isConduitFrame(BlockState state, LevelReader level, BlockPos pos, BlockPos conduit) {
        return  state.m_60734_() == Blocks.f_50377_ ||
                state.m_60734_() == Blocks.f_50378_ ||
                state.m_60734_() == Blocks.f_50386_ ||
                state.m_60734_() == Blocks.f_50379_;
    }

    /**
     * Determines if this block can be used as part of a frame of a nether portal.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @return True, to support being part of a nether portal frame, false otherwise.
     */
    default boolean isPortalFrame(BlockState state, BlockGetter level, BlockPos pos) {
        return state.m_60713_(Blocks.f_50080_);
    }

   /**
    * Gathers how much experience this block drops when broken.
    *
    * @param state The current state
    * @param level The level
    * @param randomSource Random source to use for experience randomness
    * @param pos Block position
    * @param fortuneLevel fortune enchantment level of tool being used
    * @param silkTouchLevel silk touch enchantment level of tool being used
    * @return Amount of XP from breaking this block.
    */
    default int getExpDrop(BlockState state, LevelReader level, RandomSource randomSource, BlockPos pos, int fortuneLevel, int silkTouchLevel) {
       return 0;
    }

    default BlockState rotate(BlockState state, LevelAccessor level, BlockPos pos, Rotation direction) {
        return state.m_60717_(direction);
    }

   /**
    * Determines the amount of enchanting power this block can provide to an enchanting table.
    * @param level The level
    * @param pos Block position in level
    * @return The amount of enchanting power this block produces.
    */
    default float getEnchantPowerBonus(BlockState state, LevelReader level, BlockPos pos) {
        return state.m_204336_(BlockTags.f_278384_) ? 1: 0;
    }

   /**
    * Called when a tile entity on a side of this block changes is created or is destroyed.
    * @param level The level
    * @param pos Block position in level
    * @param neighbor Block position of neighbor
    */
    default void onNeighborChange(BlockState state, LevelReader level, BlockPos pos, BlockPos neighbor){}

   /**
    * Called to determine whether to allow the block to handle its own indirect power rather than using the default rules.
    * @param level The level
    * @param pos Block position in level
    * @param side The INPUT side of the block to be powered - ie the opposite of this block's output side
    * @return Whether Block#isProvidingWeakPower should be called when determining indirect power
    */
    default boolean shouldCheckWeakPower(BlockState state, SignalGetter level, BlockPos pos, Direction side) {
        return state.m_60796_(level, pos);
    }

    /**
     * If this block should be notified of weak changes.
     * Weak changes are changes 1 block away through a solid block.
     * Similar to comparators.
     *
     * @param level The current level
     * @param pos Block position in level
     * @return true To be notified of changes
     */
    default boolean getWeakChanges(BlockState state, LevelReader level, BlockPos pos) {
        return false;
    }

    /**
     * Sensitive version of getSoundType
     * @param state The state
     * @param level The level
     * @param pos The position. Note that the level may not necessarily have {@code state} here!
     * @param entity The entity that is breaking/stepping on/placing/hitting/falling on this block, or null if no entity is in this context
     * @return A SoundType to use
     */
    SoundType getSoundType(BlockState state, LevelReader level, BlockPos pos, @Nullable Entity entity);

    /**
     * @param state The state
     * @param level The level
     * @param pos The position of this state
     * @param beaconPos The position of the beacon
     * @return A ARGB32 color to merge info the beacon's existing beam color, or -1 to do nothing to the beam
     */
    @Nullable
    default int getBeaconColorMultiplier(BlockState state, LevelReader level, BlockPos pos, BlockPos beaconPos) {
        if (self() instanceof BeaconBeamBlock beam)
            return beam.m_7988_().m_340318_();
        return -1;
    }

    /**
     * Used to determine the state 'viewed' by an entity (see
     * {@link Camera#getBlockAtCamera()}).
     * Can be used by fluid blocks to determine if the viewpoint is within the fluid or not.
     *
     * @param state     the state
     * @param level     the level
     * @param pos       the position
     * @param viewpoint the viewpoint
     * @return the block state that should be 'seen'
     */
    default BlockState getStateAtViewpoint(BlockState state, BlockGetter level, BlockPos pos, Vec3 viewpoint) {
        return state;
    }

    /**
     * Gets the path type of this block when an entity is pathfinding. When
     * {@code null}, uses vanilla behavior.
     *
     * @param state the state of the block
     * @param level the level which contains this block
     * @param pos the position of the block
     * @param mob the mob currently pathfinding, may be {@code null}
     * @return the path type of this block
     */
    @Nullable
    default PathType getBlockPathType(BlockState state, BlockGetter level, BlockPos pos, @Nullable Mob mob) {
        return state.m_60734_() == Blocks.f_49991_ ? PathType.LAVA : state.isBurning(level, pos) ? PathType.DAMAGE_FIRE : null;
    }

    /**
     * Gets the path type of the adjacent block to a pathfinding entity.
     * Path types with a negative malus are not traversable for the entity.
     * Pathfinding entities will favor paths consisting of a lower malus.
     * When {@code null}, uses vanilla behavior.
     *
     * @param state the state of the block
     * @param level the level which contains this block
     * @param pos the position of the block
     * @param mob the mob currently pathfinding, may be {@code null}
     * @param originalType the path type of the source the entity is on
     * @return the path type of this block
     */
    @Nullable
    default PathType getAdjacentBlockPathType(BlockState state, BlockGetter level, BlockPos pos, @Nullable Mob mob, PathType originalType) {
        if (state.m_60713_(Blocks.f_50685_)) return PathType.DANGER_OTHER;
        else if (WalkNodeEvaluator.m_321676_(state)) return PathType.DANGER_FIRE;
        else return null;
    }

    /**
     * @param state The state
     * @return true if the block is sticky block which used for pull or push adjacent blocks (use by piston)
     */
    default boolean isSlimeBlock(BlockState state) {
        return state.m_60734_() == Blocks.f_50374_;
    }

    /**
     * @param state The state
     * @return true if the block is sticky block which used for pull or push adjacent blocks (use by piston)
     */
    default boolean isStickyBlock(BlockState state) {
        return state.m_60734_() == Blocks.f_50374_ || state.m_60734_() == Blocks.f_50719_;
    }

    /**
     * Determines if this block can stick to another block when pushed by a piston.
     * @param state My state
     * @param other Other block
     * @return True to link blocks
     */
    default boolean canStickTo(BlockState state, BlockState other) {
        if (state.m_60734_() == Blocks.f_50719_ && other.m_60734_() == Blocks.f_50374_) return false;
        if (state.m_60734_() == Blocks.f_50374_ && other.m_60734_() == Blocks.f_50719_) return false;
        return state.isStickyBlock() || other.isStickyBlock();
    }

    /**
     * Chance that fire will spread and consume this block.
     * 300 being a 100% chance, 0, being a 0% chance.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param direction The direction that the fire is coming from
     * @return A number ranging from 0 to 300 relating used to determine if the block will be consumed by fire
     */
    default int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return ((FireBlock)Blocks.f_50083_).m_221164_(state);
    }

    /**
     * Called when fire is updating, checks if a block face can catch fire.
     *
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param direction The direction that the fire is coming from
     * @return True if the face can be on fire, false otherwise.
     */
    default boolean isFlammable(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getFlammability(level, pos, direction) > 0;
    }

    /**
     * If the block is flammable, this is called when it gets lit on fire.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param direction The direction that the fire is coming from
     * @param igniter The entity that lit the fire
     * @return {@code true} if the block <strong>SHOULD BE REMOVED</strong>
     */
    default boolean onCaughtFire(BlockState state, Level level, BlockPos pos, @Nullable Direction direction, @Nullable LivingEntity igniter) {
        return false;
    }

    /**
     * Called when fire is updating on a neighbor block.
     * The higher the number returned, the faster fire will spread around this block.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param direction The direction that the fire is coming from
     * @return A number that is used to determine the speed of fire growth around the block
     */
    default int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return ((FireBlock)Blocks.f_50083_).m_221166_(state);
    }

    /**
     * Currently only called by fire when it is on top of this block.
     * Returning true will prevent the fire from naturally dying during updating.
     * Also prevents firing from dying from rain.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @param direction The direction that the fire is coming from
     * @return True if this block sustains fire, meaning it will never go out.
     */
    default boolean isFireSource(BlockState state, LevelReader level, BlockPos pos, Direction direction) {
        return state.m_204336_(level.m_6042_().f_63836_());
    }

    /**
     * Determines if this block is can be destroyed by the specified entities normal behavior.
     *
     * @param state The current state
     * @param level The current level
     * @param pos Block position in level
     * @return True to allow the ender dragon to destroy this block
     */
    default boolean canEntityDestroy(BlockState state, BlockGetter level, BlockPos pos, Entity entity) {
        if (entity instanceof EnderDragon) {
            return !this.self().m_49966_().m_204336_(BlockTags.f_13069_);
        } else if ((entity instanceof WitherBoss) ||
                   (entity instanceof WitherSkull)) {
            return state.m_60795_() || WitherBoss.m_31491_(state);
        }

        return true;
    }

    /**
     * Determines if this block should drop loot when exploded.
     */
    default boolean canDropFromExplosion(BlockState state, BlockGetter level, BlockPos pos, Explosion explosion) {
        return state.m_60734_().m_6903_(explosion);
    }

    /**
     * Called when the block is destroyed by an explosion.
     * Useful for allowing the block to take into account tile entities,
     * state, etc. when exploded, before it is removed.
     *
     * @param level The current level
     * @param pos Block position in level
     * @param explosion The explosion instance affecting the block
     */
    default void onBlockExploded(BlockState state, ServerLevel level, BlockPos pos, Explosion explosion) {
        level.m_7731_(pos, Blocks.f_50016_.m_49966_(), 3);
        self().m_7592_(level, pos, explosion);
    }

    /**
     * Determines if this block's collision box should be treated as though it can extend above its block space.
     * Use this to replicate fence and wall behavior.
     */
    default boolean collisionExtendsVertically(BlockState state, BlockGetter level, BlockPos pos, Entity collidingEntity) {
        return state.m_204336_(BlockTags.f_13039_) || state.m_204336_(BlockTags.f_13032_) || self() instanceof FenceGateBlock;
    }

    /**
     * Called to determine whether this block should use the fluid overlay texture or flowing texture when it is placed under the fluid.
     *
     * @param state The current state
     * @param level The level
     * @param pos Block position in level
     * @param fluidState The state of the fluid
     * @return Whether the fluid overlay texture should be used
     */
    default boolean shouldDisplayFluidOverlay(BlockState state, BlockAndTintGetter level, BlockPos pos, FluidState fluidState) {
        return state.m_60734_() instanceof HalfTransparentBlock || state.m_60734_() instanceof LeavesBlock;
    }

    /**
     * Returns the state that this block should transform into when right-clicked by a tool.
     * For example: Used to determine if {@link ToolActions#AXE_STRIP an axe can strip},
     * {@link ToolActions#SHOVEL_FLATTEN a shovel can path}, or {@link ToolActions#HOE_TILL a hoe can till}.
     * Returns {@code null} if nothing should happen.
     *
     * @param state The current state
     * @param context The use on context that the action was performed in
     * @param toolAction The action being performed by the tool
     * @param simulate If {@code true}, no actions that modify the world in any way should be performed. If {@code false}, the world may be modified.
     * @return The resulting state after the action has been performed
     */
    @Nullable
    default BlockState getToolModifiedState(BlockState state, UseOnContext context, ToolAction toolAction, boolean simulate) {
        ItemStack itemStack = context.m_43722_();
        if (!itemStack.canPerformAction(toolAction))
            return null;

        if (ToolActions.AXE_STRIP == toolAction) {
            return AxeItem.getAxeStrippingState(state);
        } else if (ToolActions.AXE_SCRAPE == toolAction) {
            return WeatheringCopper.m_154899_(state).orElse(null);
        } else if (ToolActions.AXE_WAX_OFF == toolAction) {
            return Optional.ofNullable(HoneycombItem.f_150864_.get().get(state.m_60734_())).map(block -> block.m_152465_(state)).orElse(null);
        } else if (ToolActions.SHOVEL_FLATTEN == toolAction) {
            return ShovelItem.getShovelPathingState(state);
        } else if (ToolActions.HOE_TILL == toolAction) {
            // Logic copied from HoeItem#TILLABLES; needs to be kept in sync during updating
            Block block = state.m_60734_();
            if (block == Blocks.f_152549_) {
                if (!simulate && !context.m_43725_().f_46443_) {
                    Block.m_152435_(context.m_43725_(), context.m_8083_(), context.m_43719_(), new ItemStack(Items.f_151017_));
                }
                return Blocks.f_50493_.m_49966_();
            } else if ((block == Blocks.f_50440_ || block == Blocks.f_152481_ || block == Blocks.f_50493_ || block == Blocks.f_50546_) &&
                    context.m_43725_().m_8055_(context.m_8083_().m_7494_()).m_60795_()) {
                return block == Blocks.f_50546_ ? Blocks.f_50493_.m_49966_() : Blocks.f_50093_.m_49966_();
            }
        }

        return null;
    }

    /**
     * Checks if a player or entity handles movement on this block like scaffolding.
     *
     * @param state The current state
     * @param level The current level
     * @param pos The block position in level
     * @param entity The entity on the scaffolding
     * @return True if the block should act like scaffolding
     */
    default boolean isScaffolding(BlockState state, LevelReader level, BlockPos pos, LivingEntity entity) {
        return state.m_60713_(Blocks.f_50616_);
    }

    /**
     * Whether redstone dust should visually connect to this block on a given side
     * <p>
     * The default implementation is identical to
     * {@code RedStoneWireBlock#shouldConnectTo(BlockState, Direction)}
     *
     * <p>
     * {@link RedStoneWireBlock} updates its visual connection when
     * {@link BlockState#updateShape(Direction, BlockState, LevelAccessor, BlockPos, BlockPos)}
     * is called, this callback is used during the evaluation of its new shape.
     *
     * @param state The current state
     * @param level The level
     * @param pos The block position in level
     * @param direction The coming direction of the redstone dust connection (with respect to the block at pos)
     * @return True if redstone dust should visually connect on the side passed
     * <p>
     * If the return value is evaluated based on level and pos (e.g. from BlockEntity), then the implementation of
     * this block should notify its neighbors to update their shapes when necessary. Consider using
     * {@link BlockState#updateNeighbourShapes(LevelAccessor, BlockPos, int, int)} or
     * {@link BlockState#updateShape(Direction, BlockState, LevelAccessor, BlockPos, BlockPos)}.
     * <p>
     * Example:
     * <p>
     * 1. {@code yourBlockState.updateNeighbourShapes(level, yourBlockPos, UPDATE_ALL);}
     * <p>
     * 2. {@code neighborState.updateShape(fromDirection, stateOfYourBlock, level, neighborBlockPos, yourBlockPos)},
     * where {@code fromDirection} is defined from the neighbor block's point of view.
     */
    default boolean canConnectRedstone(BlockState state, BlockGetter level, BlockPos pos, @Nullable Direction direction) {
        if (state.m_60713_(Blocks.f_50088_)) {
            return true;
        } else if (state.m_60713_(Blocks.f_50146_)) {
            Direction facing = state.m_61143_(RepeaterBlock.f_54117_);
            return facing == direction || facing.m_122424_() == direction;
        } else if (state.m_60713_(Blocks.f_50455_)) {
            return direction == state.m_61143_(ObserverBlock.f_52588_);
        } else {
            return state.m_60803_() && direction != null;
        }
    }

    /**
     * Whether this block hides the neighbors face pointed towards by the given direction.
     * <p>
     * This method should only be used for blocks you don't control, for your own blocks override
     * {@link Block#skipRendering(BlockState, BlockState, Direction)} on the respective block instead
     * <p>
     * WARNING: This method is likely to be called from a worker thread! If you want to retrieve a
     *          {@link net.minecraft.world.level.block.entity.BlockEntity} from the given level, make sure to use
     *          {@link net.minecraftforge.common.extensions.IForgeBlockGetter#getExistingBlockEntity(BlockPos)} to not
     *          accidentally create a new or delete an old {@link net.minecraft.world.level.block.entity.BlockEntity}
     *          off of the main thread as this would cause a write operation to the given {@link BlockGetter} and cause
     *          a CME in the process. Any other direct or indirect write operation to the {@link BlockGetter} will have
     *          the same outcome.
     *
     * @param level The world
     * @param pos The blocks position in the world
     * @param state The blocks {@link BlockState}
     * @param neighborState The neighboring blocks {@link BlockState}
     * @param dir The direction towards the neighboring block
     */
    default boolean hidesNeighborFace(BlockGetter level, BlockPos pos, BlockState state, BlockState neighborState, Direction dir) {
        return false;
    }

    /**
     * Whether this block allows a neighboring block to hide the face of this block it touches.
     * If this returns true, {@link IForgeBlockState#hidesNeighborFace(BlockGetter, BlockPos, BlockState, Direction)}
     * will be called on the neighboring block.
     */
    default boolean supportsExternalFaceHiding(BlockState state) {
        if (FMLEnvironment.dist.isClient()) {
            return !ForgeHooksClient.isBlockInSolidLayer(state);
        }
        return true;
    }

    /**
     * Called after the {@link BlockState} at the given {@link BlockPos} was changed and neighbors were updated.
     * This method is called on the server and client side.
     * Modifying the level is disallowed in this method.
     * Useful for calculating additional data based on the new state and the neighbor's reactions to the state change.
     *
     * @param level The level the state was modified in
     * @param pos The blocks position in the level
     * @param oldState The previous state of the block at the given position, may be a different block than this one
     * @param newState The new state of the block at the given position
     */
    default void onBlockStateChange(LevelReader level, BlockPos pos, BlockState oldState, BlockState newState) { }

    /**
     * Returns whether the block can be hydrated by a fluid.
     *
     * <p>Hydration is an arbitrary word which depends on the block.
     * <ul>
     *     <li>A farmland has moisture</li>
     *     <li>A sponge can soak up the liquid</li>
     *     <li>A coral can live</li>
     * </ul>
     *
     * @param state the state of the block being hydrated
     * @param getter the getter which can get the block
     * @param pos the position of the block being hydrated
     * @param fluid the state of the fluid
     * @param fluidPos the position of the fluid
     * @return {@code true} if the block can be hydrated, {@code false} otherwise
     */
    default boolean canBeHydrated(BlockState state, BlockGetter getter, BlockPos pos, FluidState fluid, BlockPos fluidPos) {
        return fluid.canHydrate(getter, fluidPos, state, pos);
    }

    /**
     * Returns the {@link MapColor} shown on the map.
     *
     * @param state The state of this block
     * @param level The level this block is in
     * @param pos The blocks position in the level
     * @param defaultColor The {@code MapColor} configured for the given {@code BlockState} in the {@link BlockBehaviour.Properties}
     */
    default MapColor getMapColor(BlockState state, BlockGetter level, BlockPos pos, MapColor defaultColor) {
        return defaultColor;
    }

    /**
     * Returns the {@link BlockState} that this block reports to look like on the given side, for querying by other mods.
     * Note: Overriding this does not change how this block renders. That must still be handled in the block's model.
     * <p>
     * Common implementors would be covers and facades, or any other mimic blocks that proxy another block's model.
     * Common consumers would be models with connected textures that wish to seamlessly connect to mimic blocks.
     * <p>
     * <b>Note that this method may be called on the server, or on any of the client's meshing threads.</b><br/>
     * As such, if you need any data from your {@link BlockEntity}, you should put it in {@link ModelData} to guarantee
     * safe concurrent access to it on the client.<br/>
     * Calling {@link BlockGetter#getModelDataManager()} will return {@code null} if in a server context, where it is
     * safe to query your {@link BlockEntity} directly. Otherwise, {@link ModelDataManager#getAt(BlockPos)} will return
     * the {@link ModelData} for the queried block, or {@code null} if none is present.
     *
     * @param state      The state of this block
     * @param level      The level this block is in
     * @param pos        The block's position in the level
     * @param side       The side of the block that is being queried
     * @param queryState The state of the block that is querying the appearance, or {@code null} if not applicable
     * @param queryPos   The position of the block that is querying the appearance, or {@code null} if not applicable
     * @return The appearance of this block on the given side. By default, the current state
     * @see IForgeBlockState#getAppearance(BlockAndTintGetter, BlockPos, Direction, BlockState, BlockPos)
     */
    default BlockState getAppearance(BlockState state, BlockAndTintGetter level, BlockPos pos, Direction side, @Nullable BlockState queryState, @Nullable BlockPos queryPos) {
        return state;
    }

    /**
     * Returns the reaction of the block when pushed or pulled by a piston. This method should be not called directly, instead via {@link BlockState#getPistonPushReaction()}.
     * <ul>
     *     <li>NORMAL: is pushable and pullable by sticky pistons</li>
     *     <li>DESTROY: is being destroyed on pushing and pulling</li>
     *     <li>BLOCK: is not being able to be moved</li>
     *     <li>IGNORE: only usable by entities</li>
     *     <li>PUSH_ONLY: can only be pushed, blocks on trying to be pulled</li>
     *     <li>{@code null}: use the PistonPushReaction from the BlockBehaviour.Properties passed into the Block Constructor</li>
     * </ul>
     *
     * @param state The state of this block
     * @return the PushReaction of this state or {@code null} if the one passed into the block properties should be used
     */
    @Nullable
    default PushReaction getPistonPushReaction(BlockState state) {
        return null;
    }
}
